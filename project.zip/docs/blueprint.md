# **App Name**: BinaaConnect

## Core Features:

- Geolocated Damage Reporter: Enables citizens to capture photos of infrastructure damage with automatic GPS coordinate harvesting for administrative review.
- AI Damage Validator: An AI-powered tool that analyzes reported photos to categorize damage types (e.g., pothole, lighting) and initial severity scores.
- Admin Management Hub: Dashboard for admins to set repair costs, define technical specs, and approve reports for the public donation feed.
- Crowdfunding Pulse: Integrates Firebase Realtime Database to track project funding in real-time, showing contributors remaining amounts for each site.
- Secure Auth & Access: Email-based authentication with link verification to manage unique roles for citizens, donors, and verified contractors.
- Contractor Acceptance Portal: Dedicated view for vetted contractors to claim fully-funded projects and view execution guidelines set by administration.

## Style Guidelines:

- A light color scheme centered around 'Civic Stability'. The primary color is a deep professional blue (#2953A3).
- The background is a subtle, desaturated version of the primary (#F7F9FC) to maintain a clean and reliable look.
- The accent color is a bright cyan (#17B1CF), roughly 30 degrees from the primary on the hue wheel, used for positive progress bars.
- A pairing of 'Space Grotesk' for technical headlines and 'Inter' for highly readable, modern body text.
- Clean, outlined icons that distinguish clearly between report types, administrative tasks, and financial contributions.
- Card-based interface prioritizing visual photo evidence and real-time funding status bars.
- Micro-transitions for real-time progress bar updates as donations occur, providing immediate feedback.